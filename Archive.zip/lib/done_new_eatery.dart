import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_credit_card/credit_card_form.dart';
import 'package:flutter_credit_card/credit_card_model.dart';
import 'dart:convert';
import 'package:flutter_credit_card/flutter_credit_card.dart';

class DoneNewPlacePage extends StatefulWidget {
  @override
  _DoneNewPlacePageState createState() => _DoneNewPlacePageState();
}

class _DoneNewPlacePageState extends State<DoneNewPlacePage> {
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  Map userInfo;

  String _error;
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  void onCreditCardModelChange(CreditCardModel creditCardModel) {
    setState(() {
      cardNumber = creditCardModel.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Flexible(
              child: Container(),
            ),
            Text(
              "Thank you! 🤝",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Text(
              "We will verify \"[PlaceName]\" shortly\nbefore it is added to the app.",
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold),textAlign: TextAlign.center,
            ),
            Flexible(
              child: Container(),
            ),

            ButtonTheme(
              child: RaisedButton(
                color: Color(0xff2DC92D),
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                ),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) => DoneNewPlacePage())),
                child: Text(
                  "Submit",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 20,
                  ),
                ),
              ),
              minWidth: MediaQuery.of(context).size.width,
              height: 50,
            ),
            SizedBox(
              height: 20,
            )
          ],
        ),
      ),
    );
  }
}
