import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'done_new_eatery.dart';

class ConfirmNewPlacePage extends StatefulWidget {
  @override
  _ConfirmNewPlacePageState createState() => _ConfirmNewPlacePageState();
}

class _ConfirmNewPlacePageState extends State<ConfirmNewPlacePage> {
  bool map = false;

  Widget listWidget() {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  alignment: Alignment.center,
                  height: 50,
                  width: MediaQuery.of(context).size.width * 0.27,
                  padding: EdgeInsets.all(10),
                  child: Text(
                    "Name",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  decoration: BoxDecoration(
                      color: Color(0xff2DC92D),
                      borderRadius:
                          BorderRadius.horizontal(left: Radius.circular(20))),
                ),
                SizedBox(
                  width: 1,
                ),
                Container(
                  alignment: Alignment.center,
                  height: 50,
                  width: MediaQuery.of(context).size.width * 0.27,
                  padding: EdgeInsets.all(10),
                  child: Text(
                    "Submit",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  decoration: BoxDecoration(
                      color: Color(0xff2DC92D),
//                      borderRadius:
//                      BorderRadius.horizontal(right: Radius.circular(20))
                  ),
                ),SizedBox(
                  width: 1,
                ),
                Container(
                  alignment: Alignment.center,
                  height: 50,
                  width: MediaQuery.of(context).size.width * 0.27,
                  padding: EdgeInsets.all(10),
                  child: Text(
                    "Location",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.white),
                  ),
                  decoration: BoxDecoration(
                      color: Color(0xff2DC92D),
                      borderRadius:
                          BorderRadius.horizontal(right: Radius.circular(20))),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "Eatery Name:",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            SizedBox(
              height: 15,
            ),
            TextField(
              decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: InputBorder.none),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              "Eatery location:",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            SizedBox(
              height: 15,
            ),
            TextField(
              decoration: InputDecoration(
                  filled: true,
                  suffixIcon: Icon(Icons.location_searching),
                  fillColor: Colors.grey[200],
                  border: InputBorder.none),
            ),
            Flexible(
              child: Container(),
            ),
            ButtonTheme(
              child: RaisedButton(
                color: Color(0xff2DC92D),
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                ),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) => DoneNewPlacePage())),
                child: Text(
                  "Submit",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 20,
                  ),
                ),
              ),
              minWidth: MediaQuery.of(context).size.width,
              height: 50,
            ),
            SizedBox(
              height: 20,
            )
          ],
        ));
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        backgroundColor: Colors.white,
        title: Text(
          "Review eatery details",
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: listWidget(),
    );
  }
}
