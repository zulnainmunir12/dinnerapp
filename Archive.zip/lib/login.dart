import 'package:dinnerApp/features.dart';
import 'package:dinnerApp/reset_password.dart';
import 'package:dinnerApp/discover.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'signup.dart';

class Login extends StatefulWidget {
  @override
  _Login createState() {
    return _Login();
  }
}

class _Login extends State<Login> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ListView(children: <Widget>[
      Container(
        constraints: BoxConstraints.expand(height: 180),
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('logo2.png'), fit: BoxFit.fill)),
        child: Stack(
          children: <Widget>[
            Positioned(
              top: 15,
              child: IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                  size: 30,
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return Features();
                  }));
                },
              ),
            ),
            new Positioned(
              child: Center(
                child: Image.asset('dinewight.png'),
              ),
            )
          ],
        ),
      ),
      Container(
        height: MediaQuery.of(context).size.height*0.7,
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              height: 20,
            ),
            Center(
              child: Text(
                'Sign in',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Container(
//            width: 330,
              height: 70,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Flexible(
                    child: TextField(
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color.fromRGBO(238, 238, 238, 2),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromRGBO(238, 238, 238, 2))),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromRGBO(238, 238, 238, 2))),
                        hintText: "Email Address",
                        hintStyle:
                            TextStyle(color: Color.fromRGBO(165, 165, 165, 2)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 5,
            ),
            Container(
//            width: 330,
              height: 70,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Flexible(
                    child: TextField(
                      cursorColor: Colors.black,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Color.fromRGBO(238, 238, 238, 2),
                        focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromRGBO(238, 238, 238, 2))),
                        enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Color.fromRGBO(238, 238, 238, 2))),
                        hintText: "Email Address",
                        hintStyle:
                            TextStyle(color: Color.fromRGBO(165, 165, 165, 2)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
           InkWell(child: Text(
              "Forgot password?",
              style: TextStyle(
                  color: Color(0xff2DC92D),
                  fontSize: 16,
                  fontWeight: FontWeight.bold),
            ),onTap: ()=> Navigator.push(context,
               MaterialPageRoute(builder: (context) {
                 return ResetPassword();
               })),) ,
            SizedBox(
              height: 20,
            ),
            Center(
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 50,
                child: RaisedButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        side:
                            BorderSide(color: Color.fromRGBO(54, 191, 54, 2))),
                    color: Color.fromRGBO(54, 191, 54, 2),
                    child: Text(
                      'Sign in',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return DiscoverPage();
                      }));
                    }),
              ),
            ), SizedBox(height: 10,), Center(
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 50,
                child: FlatButton(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        side:
                            BorderSide(color: Colors.grey)),
//                    color: Color.fromRGBO(54, 191, 54, 2),
                    child: Text(
                      'Create an account',
                      style: TextStyle(
//                          color: Colors.white,
                          fontSize: 25,
                          fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                            return RegisterPage();
                          }));
//                      Navigator.push(context,
//                          MaterialPageRoute(builder: (context) {
//                        return ManageEateries();
//                      }));
                    }),
              ),
            ),
            Flexible(
              child: Container(),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[

                Text(
                  'By proceeding you agree to the DineWight\nTerms of Use and Privacy Policy.',
                  style: TextStyle(fontWeight: FontWeight.w300),
                  textAlign: TextAlign.center,
                ),

              ],
            ),
            SizedBox(height: 20,)
          ],
        ),
      ),
    ]));
  }
}
