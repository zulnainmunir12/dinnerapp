import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: AppBar(
//          elevation: 0,
          title: Text(
            "Create your account",
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: Colors.white,
        ),
        backgroundColor: Colors.white,
        body: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: ListView(
              children: <Widget>[
                Container(
                  height: MediaQuery.of(context).size.height*0.86,
                  padding: EdgeInsets.fromLTRB(30, 20, 30, 0),
                  child: Column(
                    children: <Widget>[
                      new Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Flexible(
                              child: Container(
                            width: MediaQuery.of(context).size.width * 0.5,
                            color: Color(0xffEEEEEE),
                            child: TextFormField(
                              style: TextStyle(
                                color: Colors.black,
                              ),
                              decoration: InputDecoration(
                                  border: InputBorder.none,
                                  labelText: 'First Name',
                                  contentPadding: const EdgeInsets.only(
                                      left: 12, top: 12, bottom: 12, right: 12),
                                  labelStyle: TextStyle(fontSize: 16)),
                            ),
                          )),
                          SizedBox(
                            width: 20,
                          ),
                          Flexible(
                            child: Container(
                              color: Color(0xffEEEEEE),
                              child: TextFormField(
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    labelText: 'Last Name',
                                    contentPadding: const EdgeInsets.only(
                                        left: 12,
                                        top: 12,
                                        bottom: 12,
                                        right: 12),
                                    labelStyle: TextStyle(fontSize: 16)),
                              ),
                            ),
                          ),
                        ],
                      ),
//
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 15, 0, 15),
                        child: Container(
                          color: Color(0xffEEEEEE),
                          child: TextFormField(
                            style: TextStyle(
                              color: Colors.black,
                            ),
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                labelText: 'Email Address',
                                contentPadding: const EdgeInsets.only(
                                    left: 12, top: 12, bottom: 12, right: 12),
                                labelStyle: TextStyle(fontSize: 16)),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                        child: Container(
                          color: Color(0xffEEEEEE),
                          child: TextFormField(
                            obscureText: true,
                            style: TextStyle(
                              color: Colors.black,
                            ),
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                labelText: 'Password',
                                contentPadding: const EdgeInsets.only(
                                    left: 12, top: 12, bottom: 12, right: 12),
                                labelStyle: TextStyle(fontSize: 16)),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Row(
//                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Checkbox(
                            onChanged: (val) {},
                            value: false,
                          ),
                          RichText(
                            text: TextSpan(children: <TextSpan>[
                              TextSpan(
                                  text:
                                      "Receive emails for new features and news",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black)),
                              TextSpan(
                                  text:
                                      "\nSend me tasty deals, updates on new features\nand relevant news about DineWight.",
                                  style: TextStyle(
                                      fontSize: 12, color: Colors.black))
                            ]),
                            textAlign: TextAlign.start,
                          ),
                        ],
                      ),
                      Flexible(child: Container(),),
                      Text(
                        'By proceeding you agree to the DineWight\nTerms of Use and Privacy Policy.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xff202120),
                          fontSize: 16.0,
                        ),
                      ),

                      Padding(
                        padding: EdgeInsets.only(top: 20),
                        child: MaterialButton(
                          onPressed: () => Navigator.pushNamed(
                              context, "/info"), //since this is only a UI app
                          child: Text(
                            'Next',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          color: Color(0xFF36BF36),
                          elevation: 0,
                          minWidth: 400,
                          height: 50,
                          textColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            )));
  }
}
