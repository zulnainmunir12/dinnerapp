//import 'package:dining_app/discovery/search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class EateryDetailPage extends StatefulWidget {
  @override
  _EateryDetailPageState createState() => _EateryDetailPageState();
}

class _EateryDetailPageState extends State<EateryDetailPage>
    with SingleTickerProviderStateMixin {
  bool map = false;
  TabController _tabController;

  @override
  void initState() {
    _tabController = new TabController(length: 3, vsync: this);
    super.initState();
  }

  Widget listWidget() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Image.asset(
              "rails.png",
              height: 180,
              fit: BoxFit.fitWidth,
              width: MediaQuery.of(context).size.width,
            ),
            Container(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        "The Rails",
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      Row(
                        children: <Widget>[
                          Icon(Icons.local_dining),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "British",
                            style: TextStyle(fontSize: 14),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Icon(Icons.location_on),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Newport",
                            style: TextStyle(fontSize: 14),
                          ),
                          Flexible(
                            child: Container(),
                          ),
                          Text(
                            "1.3 mi",
                            style: TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                      Row(
                        children: <Widget>[
                          Icon(Icons.star),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "4.0 (123)",
                            style: TextStyle(fontSize: 14),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            "£6 - £42",
                            style: TextStyle(fontSize: 14),
                          ),
                          Flexible(
                            child: Container(),
                          ),
                          Text(
                            "4 min",
                            style: TextStyle(fontSize: 14),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(Icons.directions_car)
                        ],
                      ),
                    ])),
            SizedBox(
              height: 10,
            ),
            TabBar(

              labelColor: Color(0xff2DC92D),
              tabs: <Widget>[
                new Tab(
                  text:  "Book"
                ),
                new Tab(
                  text:"Menu"
                ),
                new Tab(
                  text:"Reviews"
                ),
              ],
              controller: _tabController,
            ),
            Flexible(
              child: TabBarView(
                children: [
                  Container(child:  ListView(
                    children: <Widget>[
                      SizedBox(height: 10,),
                      Container(
                        margin: EdgeInsets.only(left: 10),
                        padding: EdgeInsets.all(5),
                        child: Row(mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(
                              width: 10,
                            ),
                            Icon(Icons.people),
                            SizedBox(
                              width: 5,
                            ),
                            Text("2"),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Icon(Icons.calendar_today),
                            SizedBox(
                              width: 5,
                            ),
                            Text("Today"),SizedBox(
                              width: 10,
                            ),
                            Icon(Icons.access_time),
                            SizedBox(
                              width: 5,
                            ),
                            Text("12:30"),
                            SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.grey[300])),
                      ),
                      SizedBox(height: 10,),
                      Row(
                        children: <Widget>[
                          Card(
                            color: Color.fromRGBO(54, 191, 54, 1.0),
                            child: Column(
                              children: <Widget>[
                                Center(
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 5),
                                      child: Text(
                                        "16:30",
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    )),
                                Center(
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 5),
                                      child: Text(
                                        "50%",
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    )),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Card(
                            color: Color.fromRGBO(54, 191, 54, 1.0),
                            child: Column(
                              children: <Widget>[
                                Center(
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 5),
                                      child: Text(
                                        "16:30",
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    )),
                                Center(
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 5),
                                      child: Text(
                                        "25%",
                                        style: TextStyle(color: Colors.white),
                                      ),
                                    )),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Card(
                            color: Color.fromRGBO(54, 191, 54, 1.0),
                            child: Center(
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 5),
                                  child: Text(
                                    "16:30",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                )),
                          ),
                        ],
                      ),
                    ],
                  ),padding: EdgeInsets.symmetric(horizontal: 15),),
                  new Text("This is chat Tab View"),
                  new Text("This is notification Tab View"),
                ],
                controller: _tabController,
              ),
            )
          ],
        ));
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      body: listWidget(),
    );
  }
}
