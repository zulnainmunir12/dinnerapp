import 'package:dinnerApp/search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_tags/flutter_tags.dart';
import 'dart:convert';

class FilterPage extends StatefulWidget {
  @override
  _FilterPageState createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> {
  final GlobalKey<TagsState> _tagStateKey = GlobalKey<TagsState>();
  final List<String> _list = ['Find an Eatery', 'Find and Book'];

  List _icon = [Icons.home, Icons.language, Icons.headset];
  bool _symmetry = false;
  bool _removeButton = false;
  bool _singleItem = false;
  bool _startDirection = false;
  bool _horizontalScroll = false;
  bool _withSuggesttions = false;
  int _count = 0;
  int _column = 0;
  double _fontSize = 14;

  @override
  void initState() {
    super.initState();
//    _tabController = TabController(length: 2, vsync: this);
//    _scrollViewController = ScrollController();

    _items = _list.toList();
  }

  List _items;
  Widget get _tags1 {
    return Tags(
      key: _tagStateKey,
      symmetry: true,
      columns: 2,
      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items.length,
      itemBuilder: (index) {
        final item = _items[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color(0xffCEF3CE),
          singleItem: _singleItem,
          splashColor: Color(0xff),
          combine: ItemTagsCombine.onlyText,
          image: index > 0 && index < 5
              ? ItemTagsImage(
                  //image: AssetImage("img/p$index.jpg"),
                  child: Image.network(
                  "http://www.clipartpanda.com/clipart_images/user-66327738/download",
                  width: 16 * _fontSize / 14,
                  height: 16 * _fontSize / 14,
                ))
              : (1 == 1
                  ? ItemTagsImage(
                      image: NetworkImage(
                          "https://d32ogoqmya1dw8.cloudfront.net/images/serc/empty_user_icon_256.v2.png"),
                    )
                  : null),
          icon: (item == '0' || item == '1' || item == '2')
              ? ItemTagsIcon(
                  icon: _icon[int.parse(item)],
                )
              : null,
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(fontSize: _fontSize, color: Color(0xff2DC92D)),
          onPressed: (item) => print(item),
          textActiveColor: Color(0xff2DC92D),
        );
      },
    );
  }

  List _items2 = [
    'Any',
    'British',
    'Fish & Chips',
    'Italian',
    'Indian',
    'Chinese',
    'Pizzeria'
  ];
  Widget get _tags2 {
    return Tags(
//      key: _tagStateKey,
      symmetry: true,
      columns: 4,
//      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items2.length,

      itemBuilder: (index) {
        final item = _items2[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color.fromRGBO(67, 158, 67, 1),
          singleItem: _singleItem,
          splashColor: Colors.green,
          combine: ItemTagsCombine.onlyText,
          image: null,
          icon: null,
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => print(item),
        );
      },
    );
  }

  Widget get _tagsDialog {
    return Tags(
//      key: _tagStateKey,
      symmetry: true,
      columns: 2,
//      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items2.length,

      itemBuilder: (index) {
        final item = _items2[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color.fromRGBO(67, 158, 67, 1),
          singleItem: _singleItem,
          splashColor: Colors.green,
          combine: ItemTagsCombine.onlyText,
          image: null,
          icon: null,
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => print(item),
        );
      },
    );
  }

  List _items3 = [
    'Any',
    'Vegetarian',
    'Gluten Free',
    'Vegan',
    'Dairy Free',
    'Lactose Free',
  ];
  Widget get _tags3 {
    return Tags(
//      key: _tagStateKey,
      symmetry: true,
      columns: 4,
//      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items3.length,

      itemBuilder: (index) {
        final item = _items3[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color.fromRGBO(67, 158, 67, 1),
          singleItem: _singleItem,
          splashColor: Colors.green,
          combine: ItemTagsCombine.onlyText,
          image: null,
          icon: null,
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => print(item),
        );
      },
    );
  }

  List _items4 = [
    'Any',
    'Wheelchairs',
    'Toilets',
  ];
  Widget get _tags4 {
    return Tags(
//      key: _tagStateKey,
      symmetry: true,
      columns: 4,
//      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items4.length,

      itemBuilder: (index) {
        final item = _items4[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color.fromRGBO(67, 158, 67, 1),
          singleItem: _singleItem,
          splashColor: Colors.green,
          combine: ItemTagsCombine.onlyText,
          image: null,
          icon: null,
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => print(item),
        );
      },
    );
  }

  List _items5 = [
    '3',
    '4',
    '5',
  ];
  Widget get _tags5 {
    return Tags(
//      key: _tagStateKey,
      symmetry: true,
      columns: 4,
//      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items5.length,

      itemBuilder: (index) {
        final item = _items5[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color.fromRGBO(67, 158, 67, 1),
          singleItem: _singleItem,
          splashColor: Colors.green,
          combine: ItemTagsCombine.withTextBefore,
          image: null,
          icon: ItemTagsIcon(
            icon: Icons.star,
          ),
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => print(item),
        );
      },
    );
  }

  List _items6 = [
    'Any',
    '£',
    '££',
    '£££',
  ];
  Widget get _tags6 {
    return Tags(
//      key: _tagStateKey,
      symmetry: true,
      columns: 4,
//      horizontalScroll: _horizontalScroll,
      //verticalDirection: VerticalDirection.up, textDirection: TextDirection.rtl,
      heightHorizontalScroll: 60 * (_fontSize / 14),
      itemCount: _items6.length,

      itemBuilder: (index) {
        final item = _items6[index];

        return ItemTags(
          key: Key(index.toString()),
          index: index,
          title: item,
          pressEnabled: true,
          activeColor: Color.fromRGBO(67, 158, 67, 1),
          singleItem: _singleItem,
          splashColor: Colors.green,
          combine: ItemTagsCombine.onlyText,
          image: null,
          icon: ItemTagsIcon(
            icon: Icons.star,
          ),
          removeButton: _removeButton ? ItemTagsRemoveButton() : null,
          textScaleFactor:
              utf8.encode(item.substring(0, 1)).length > 2 ? 0.8 : 1,
          textStyle: TextStyle(
            fontSize: _fontSize,
          ),
          onPressed: (item) => print(item),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text("Filter",style: TextStyle(color: Colors.black),),
        actions: <Widget>[
          FlatButton(
            onPressed: () {},
            child: Text("CLEAR"),
          )
        ],
      ),
      body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: ListView(
            children: <Widget>[
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.sort),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Sort by",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      FlatButton(
                        color: Color(0xff2DC92D).withOpacity(0.42),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        child: Text(
                          "Incentive",
                          style: TextStyle(color: Color(0xff2DC92D)),
                        ),
                        onPressed: () {},
                      ),
                      FlatButton(
//                        color: Color.fromRGBO(67, 158, 67, 1),
                        shape: RoundedRectangleBorder(
                            side: BorderSide(color: Colors.grey),
                            borderRadius: BorderRadius.circular(15)),
                        child: Text(
                          "Distance",
                        ),
                        onPressed: () {},
                      ),
                      FlatButton(
                        shape: RoundedRectangleBorder(
                            side: BorderSide(color: Colors.grey),
                            borderRadius: BorderRadius.circular(15)),
                        child: Text(
                          "Rating",
                        ),
                        onPressed: () {},
                      ),
                    ],
                  )),
              Divider(),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.location_searching),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Experience",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: _tags1),
              Divider(),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.location_searching),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Cuisine",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                      Flexible(
                        child: Container(),
                      ),
                      FlatButton(
                        child: Text(
                          "View All",
                          style: TextStyle(
                            color: Color.fromRGBO(67, 158, 67, 1),
                          ),
                        ),
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(15))),
                                  title: Text('Cuisine'),
                                  content: Container(
//                                    padding: EdgeInsets.symmetric(
//                                      horizontal: 20,
//                                    ),
                                      child: _tagsDialog),
                                  actions: <Widget>[
                                    FlatButton(
                                      child: Text("Done"),
                                      onPressed: () => Navigator.pop(context),
                                    )
                                  ],
                                );
                              });
                        },
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: _tags2),
              Divider(),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.location_searching),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Menu Options",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: _tags3),
              Divider(),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.location_searching),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Accessibility",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: _tags4),
              Divider(),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.location_searching),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Customer Rating",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: _tags5),
              Divider(),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  child: Row(
                    children: <Widget>[
                      Icon(Icons.location_searching),
                      SizedBox(
                        width: 5,
                      ),
                      Text(
                        "Prices",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      )
                    ],
                  )),
              Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: _tags6),
              Divider(),
            ],
          )),
    );
  }
}
